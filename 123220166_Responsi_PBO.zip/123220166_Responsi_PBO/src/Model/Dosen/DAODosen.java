/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.Dosen;
import Model.Connector;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Lab Informatika
 */
public class DAODosen implements InterfaceDAODosen {

    /**
     *
     * @param dosen
     */
    public void insert(ModelDosen dosen) {
        try {
            String query = "INSERT INTO dosen (nama, nidn) VALUES (?, ?);";
            try (PreparedStatement statement = Connector.Connect().prepareStatement(query)) {
                statement.setString(1, dosen.getNama());
                statement.setString(2, dosen.getNidn());
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println("Input Failed: " + e.getLocalizedMessage());
        }
    }

    /**
     *
     * @param dosen
     */
    public void update(ModelDosen dosen) {
        try {
            String query = "UPDATE dosen SET nama=?, nidn=? WHERE id=?;";
            try (PreparedStatement statement = Connector.Connect().prepareStatement(query)) {
                statement.setString(1, dosen.getNama());
                statement.setString(2, dosen.getNidn());
                statement.setInt(3, dosen.getId());
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println("Update Failed! (" + e.getMessage() + ")");
        }
    }

    /**
     *
     * @param id
     */
    public void delete(int id) {
        try {
            String query = "DELETE FROM dosen WHERE id=?;";
            try (PreparedStatement statement = Connector.Connect().prepareStatement(query)) {
                statement.setInt(1, id);
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println("Delete Failed: " + e.getLocalizedMessage());
        }
    }

    
    public List<ModelDosen> getAll() {
        List<ModelDosen> listDosen = new ArrayList<>();
        try {
            try (Statement statement = Connector.Connect().createStatement()) {
                String query = "SELECT * FROM dosen;";
                ResultSet resultSet = statement.executeQuery(query);
                while (resultSet.next()) {
                    ModelDosen dosen = new ModelDosen();
                    dosen.setId(resultSet.getInt("id"));
                    dosen.setNama(resultSet.getString("nama"));
                    dosen.setNidn(resultSet.getString("nidn"));
                    listDosen.add(dosen);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getLocalizedMessage());
        }
        return listDosen;
    }
}
 
    
